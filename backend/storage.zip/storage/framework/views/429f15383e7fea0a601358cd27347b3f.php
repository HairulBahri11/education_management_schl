<?php $__env->startSection('active_aspekpenilaian', 'active'); ?>
<?php $__env->startSection('show_manajemennilai', 'show'); ?>
<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>!",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php elseif(session('error')): ?>
        <script>
            swal({
                title: "Oops!",
                text: "<?php echo e(session('error')); ?>!",
                icon: "error",
                button: "OK",
            });
        </script>
    <?php endif; ?>



    <div class="dashboard-content px-3 pt-5">
        <div class="container">
            <div class="row mb-2">
                <div class="container">
                    <div class="col-md-5">
                        <h4 style="font-weight: bold">Aspek Penilaian</h4>
                    </div>
                    <div class="col-md-5 ms-auto">
                        <div class="float-end">
                            <a href="<?php echo e(route('aspekpenilaian.create')); ?>"
                                class="btn btn-sm custom-btn-primary text-white hover-btn"><i
                                    class="fa-solid fa-circle-plus text-white"></i>Tambah Aspek</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="box-content">
                        <div class="col">
                            <div class="p-3">
                                <div class="table-responsive">
                                    <table class="table table-hover" id="example">
                                        <thead class="bg-gray-100 p-1">
                                            <tr style="bg-color: black" class="mt-2">
                                                <th class="text-xs text-secondary opacity-7 align-middle">Aspek Penilaian
                                                </th>
                                                <th class="text-xs text-secondary opacity-7 align-middle">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php echo e($item->aspek_penilaian); ?></td>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <a href="<?php echo e(route('aspekpenilaian_detail.show', $item->id)); ?>"
                                                            class="btn btn-sm custom-btn-edit text-white hover-btn"
                                                            style="font-weight: bold" title="Detail">
                                                            <i class="fa-solid fa-eye text-white fs-10"></i>
                                                        </a>

                                                        <form action="<?php echo e(route('aspekpenilaian.destroy', $item->id)); ?>"
                                                            method="POST" style="display: inline-block;">
                                                            <?php echo method_field('DELETE'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit"
                                                                class="btn btn-sm custom-btn-hapus hover-btn"
                                                                title="Hapus Aspek" data-id="<?php echo e($item->id); ?>"
                                                                onclick="return confirm('apakah kamu yakin ingin menghapus data?')"><i
                                                                    class="fa-solid fa-trash text-white fs-10"></i></button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/aspek_penilaian/aspek_penilaian.blade.php ENDPATH**/ ?>