<?php $__env->startSection('active_kelas', 'active'); ?>
<?php $__env->startSection('show_manajemenkelas', 'show'); ?>
<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>!",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php elseif(session('error')): ?>
        <script>
            swal({
                title: "Oops!",
                text: "<?php echo e(session('error')); ?>!",
                icon: "error",
                button: "OK",
            });
        </script>
    <?php endif; ?>



    <div class="dashboard-content px-3 pt-5">
        <div class="container">
            <div class="row mb-2">
                <div class="container">
                    <div class="col-md-5">
                        <h2 style="font-weight: bold"><?php echo e($data->nama_kelas); ?> </h2>
                        <h5><?php echo e($data->program->nama_program); ?></h5>
                    </div>
                    <div class="col-md-5 ms-auto">
                        <div class="float-end">
                            <a href="<?php echo e(route('kelas.hal_tambahsiswa', $data->id)); ?>"
                                class="btn btn-sm custom-btn-primary text-white hover-btn"><i
                                    class="fa-solid fa-circle-plus text-white"></i>Tambah Siswa</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="box-content">
                    <div class="col">
                        <div class="p-3">
                            <div class="table-responsive">
                                
                                <table class="table table-hover" id="example">
                                    <thead class="bg-gray-100 p-1">
                                        <tr style="bg-color: black" class="mt-2">
                                            <th class="text-xs text-secondary opacity-7">Foto</th>
                                            <th class="text-xs text-secondary opacity-7">Kode Siswa</th>
                                            <th class="text-xs text-secondary opacity-7">Nama Siswa
                                            </th>
                                            <th class="text-xs text-secondary opacity-7">Gender</th>
                                            <th class="text-xs text-secondary opacity-7">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td align-middle>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <img src="<?php echo e(asset('storage/images/' . $item->siswa->foto)); ?>"
                                                                width="100" height="100" alt="gambar">
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="text-secondary opacity-7 align-middle">
                                                    <div class="user-info " align="center">
                                                        <p><?php echo e($item->siswa->kode_siswa); ?></p>
                                                        <?php echo QrCode::size(50)->generate($item->siswa->kode_siswa); ?>

                                                    </div>
                                                </td>
                                                <td class="text-secondary opacity-7 align-middle">
                                                    <div class="user-info">
                                                        <p class="user-name"><?php echo e($item->siswa->nama_siswa); ?></p>
                                                    </div>
                                                </td>

                                                <td class="text-xs text-secondary opacity-7 align-middle">
                                                    <?php if($item->siswa->jenis_kelamin == 'L'): ?>
                                                        Laki Laki
                                                    <?php else: ?>
                                                        Perempuan
                                                    <?php endif; ?>
                                                </td>

                                                



                                                <td class="text-xs text-secondary opacity-7 align-middle">

                                                    <form
                                                        action="<?php echo e(route('kelas.siswa.destroy', ['idkelas' => $data->id, 'idsiswa' => $item->siswa->id])); ?>"
                                                        method="POST" style="display: inline-block;">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>


                                                        <button type="submit" class="btn btn-sm custom-btn-hapus hover-btn"
                                                            title="Delete" title="Hapus" data-id="<?php echo e($item->id); ?>"
                                                            onclick="return confirm('apakah kamu yakin ingin menghapus data formulir?')"><i
                                                                class="fa-solid fa-trash text-white fs-10"></i></button>
                                                    </form>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/kelas/kelas_detail.blade.php ENDPATH**/ ?>