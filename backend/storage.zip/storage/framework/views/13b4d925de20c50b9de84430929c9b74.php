<?php $__env->startSection('active_siswa', 'active'); ?>
<?php $__env->startSection('show_manajemensiswa', 'show'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>!",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php elseif(session('error')): ?>
        <script>
            swal({
                title: "Opps!",
                text: "<?php echo e(session('error')); ?>!",
                icon: "error",
                button: "OK",
            });
        </script>
    <?php endif; ?>
    <div class="dashboard-content px-3 pt-5">
        <div class="container">
            <div class="row mb-3">
                <div class="container">
                    <div class="col-md-5">
                        <h2 class="ms-4" style="font-weight: bold">Tambah siswa</h2>
                    </div>
                    <div class="col-md-5 float-end">
                        <form action="<?php echo e(route('siswa.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="float-end">
                                <button type="submit" class="btn custom-btn-primary hover-btn text-white"> <i
                                        class="fa-solid fa-floppy-disk text-white"></i> Simpan</button>
                            </div>
                    </div>
                </div>
            </div>

            <div class="row mb-3">
                <div class="box-content">
                    <div class="col bg-white">
                        <div class="p-5">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="exampleFormControlInput1" class="form-label">Kode Pendaftaran</label>
                                        <select name="pendaftaran_id" class="form-control"  id="pendaftaran_id"
                                            onchange="getPendaftaran()" required>
                                            <option class="form-control">--Data Pendaftaran--</option>
                                            <?php $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                                <option value="<?php echo e($pf->id); ?>" class="form-control"><?php echo e($pf->kode_pendaftaran); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleFormControlInput1" class="form-label">Nama siswa</label>
                                        <input type="text" name="nama_siswa" class="form-control" id="nama_anak"
                                            placeholder="Ex. Joghardi" required>
                                    </div>
                                    <div>
                                        <label for="exampleFormControlTextarea1" class="form-label">Jenis Kelamin</label>
                                    </div>
                                    <div class="mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="jenis_kelamin"
                                                id="jenis_kelamin1" value="L">
                                            <label class="form-check-label" for="flexRadioDefault1">
                                                Laki Laki
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="jenis_kelamin"
                                                id="flexRadioDefault2" value="P">
                                            <label class="form-check-label" for="flexRadioDefault2">
                                                Perempuan
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="exampleFormControlTextarea1" class="form-label">Foto</label>
                                        <input type="file" name="foto" class="form-control"
                                            id="exampleFormControlTextarea1" rows="3" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleFormControlTextarea1" class="form-label">Tempat Lahir </label>
                                        <input type="text" class="form-control" name="tempat_lahir"
                                            id="exampleFormControlTextarea1" rows="3" placeholder="Alamat lengkap"
                                            required></input>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleFormControlTextarea1" class="form-label">Tanggal Lahir </label>
                                        <input type="date" class="form-control" name="tgl_lahir"
                                            id="exampleFormControlTextarea1" rows="3">
                                    </div>

                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


        </div>

    <?php $__env->stopSection(); ?>

    <script>
        function getPendaftaran() {
            //    ambil pendaftaran_id berdasarkan isi selected option
            var selectedOption = $('#pendaftaran_id').find('option:selected');
            var pendaftaran_id = selectedOption.text(); // Mengambil teks yang dipilih
            console.log(pendaftaran_id);

            // / Membuat URL dengan parameter pendaftaran_id
            var url = "<?php echo e(route('pendaftaran.show', ['id' => ':id'])); ?>";
            url = url.replace(':id', pendaftaran_id);

            $.ajax({
                type: "GET",
                url: url, // Sesuaikan dengan nama rute Anda
                dataType: "json", // Jika Anda mengharapkan respons dalam format JSON
                success: function(response) {
                    console.log(response);
                    if (response.status == true) {
                        $('#nama_anak').val(response.data.nama_anak);
                    } else {
                        // buat pendaftaran_id valuenya kosong
                        $('#pendaftaran_id').val('');
                        alert('Data Pedaftaran Telah Digunakan');
                    }

                },
                error: function(xhr, status, error) {
                    console.error("Error: " + error);
                }
            });
        }
    </script>

<?php echo $__env->make('dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/siswa/siswa_create.blade.php ENDPATH**/ ?>