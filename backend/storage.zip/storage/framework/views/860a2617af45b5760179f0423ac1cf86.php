<?php $__env->startSection('active_jadwaltrial', 'active'); ?>
<?php $__env->startSection('show_manajemenkelas', 'show'); ?>
<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>!",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php elseif(session('error')): ?>
        <script>
            swal({
                title: "Oops!",
                text: "<?php echo e(session('error')); ?>!",
                icon: "error",
                button: "OK",
            });
        </script>
    <?php endif; ?>



    <div class="dashboard-content px-3 pt-5">
        <div class="container">
            <div class="row mb-2">
                <div class="container">
                    <div class="col-md-5">
                        <h4 style="font-weight: bold">Jadwal Kelas
                            <span class="text-white"
                                style="background-color: green; color: white; padding: 5px; border-radius:8px; margin-left: 10px;font-size: 12px">
                                <i>Trial</i></span>
                        </h4>

                    </div>
                    <div class="col-md-5 ms-auto">
                        <div class="float-end">
                            <a href="<?php echo e(route('jadwaltrial.create')); ?>"
                                class="btn btn-sm custom-btn-primary text-white hover-btn"><i
                                    class="fa-solid fa-circle-plus text-white"></i>Tambah Jadwal</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="box-content">
                        <div class="col">
                            <div class="p-3">
                                <div class="table-responsive">
                                    <table class="table table-hover" id="example">
                                        <thead class="bg-gray-100 p-1">
                                            <tr style="bg-color: black" class="mt-2">
                                                <th class="text-xs text-secondary opacity-7">Pengajar</th>
                                                <th class="text-xs text-secondary opacity-7">Hari</th>
                                                <th class="text-xs text-secondary opacity-7">Jam</th>
                                                <th class="text-xs text-secondary opacity-7">Kelas</th>
                                                <th class="text-xs text-secondary opacity-7">Program
                                                </th>
                                                <th class="text-xs text-secondary opacity-7">Status</th>
                                                <th class="text-xs text-secondary opacity-7">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <span>
                                                            <img src="<?php echo e(asset('storage/images/' . $item->pengajar->foto)); ?>"
                                                                class="img-fluid" width="100px" height="100px"
                                                                alt="foto">
                                                        </span>
                                                        <?php echo e($item->pengajar->nama); ?>

                                                    </td>

                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php echo e($item->hari); ?></td>

                                                    
                                                    
                                                    <?php
                                                        $status = $item->status;
                                                        if ($status == 'Aktif') {
                                                            $icon = 'fa fa-check-circle text-success';
                                                        } else {
                                                            $icon = 'fa fa-times-circle text-danger';
                                                        }
                                                    ?>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php echo e(\Illuminate\Support\Carbon::parse($item->jam_mulai)->format('H:i')); ?>

                                                        -
                                                        <?php echo e(\Illuminate\Support\Carbon::parse($item->jam_selesai)->format('H:i')); ?>

                                                    </td>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php echo e($item->kelas->nama_kelas); ?>

                                                    </td>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php echo e($item->program->nama_program); ?> -
                                                        <?php echo e($item->program->jeniskelas->nama_jenis_kelas); ?>

                                                    </td>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <span>
                                                            <i class="<?php echo e($icon); ?>"></i>
                                                            <?php echo e($item->status); ?>

                                                        </span>
                                                    </td>


                                                    <td class="text-xs text-secondary opacity-7 align-middle">


                                                        <form action="<?php echo e(route('jadwaltrial.setnonactive', $item->id)); ?>"
                                                            method="POST" style="display: inline-block;">
                                                            <?php echo method_field('POST'); ?>
                                                            <?php echo csrf_field(); ?>

                                                            <button type="submit"
                                                                class="btn btn-sm custom-btn-hapus hover-btn"
                                                                title="Ubah Status" data-id="<?php echo e($item->id); ?>"><i
                                                                    class="fa-solid fa-trash text-white fs-10"
                                                                    onclick="return confirm('apakah kamu yakin ingin mengubah status jadwal trial?')"></i></button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/jadwal-trial/jadwal-trial.blade.php ENDPATH**/ ?>