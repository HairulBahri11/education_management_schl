<?php $__env->startSection('active_pengajar', 'active'); ?>
<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>!",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php endif; ?>

    <div class="dashboard-content px-3 pt-5">
        <div class="container">
            <div class="row mb-2">
                <div class="container">
                    <div class="col-md-5">
                        <h4 style="font-weight: bold">Data Pengajar</h4>
                    </div>
                    <div class="col-md-5 ms-auto">
                        <div class="float-end">
                            <a href="<?php echo e(route('pengajar.create')); ?>"
                                class="btn btn-sm custom-btn-primary text-white hover-btn"><i
                                    class="fa-solid fa-circle-plus text-white"></i>Tambah</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="box-content">
                        <div class="col">
                            <div class="p-3">
                                <div class="table-responsive">
                                    
                                    <table class="table table-hover" id="example">
                                        <thead class="bg-gray-100 p-1">
                                            <tr style="bg-color: black" class="mt-2">
                                                <th class="text-xs text-secondary opacity-7">Foto</th>
                                                <th class="text-xs text-secondary opacity-7">Pengajar
                                                </th>
                                                <th class="text-xs text-secondary opacity-7">Whatsapp</th>
                                                <th class="text-xs text-secondary opacity-7">alamat</th>
                                                <th class="text-xs text-secondary opacity-7">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td align-middle>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <img src="<?php echo e(asset('storage/images/' . $item->foto)); ?>"
                                                                    width="100" height="100" alt="gambar">
                                                            </div>

                                                        </div>
                                                    </td>
                                                    <td class="text-secondary opacity-7 align-middle">
                                                        <div class="user-info">
                                                            <p class="user-name"><?php echo e($item->nama); ?></p>
                                                            <p class="user-email"><?php echo e($item->email); ?></p>
                                                            <?php if($item->active == 1): ?>
                                                                <i class="fas fa-check text-success"></i>Aktif
                                                            <?php else: ?>
                                                                <i class="fas fa-times text-danger"></i> Nonaktif
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>

                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php echo e($item->no_hp); ?>

                                                    </td>

                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <span>
                                                            <i class="fa-solid fa-location-dot"> </i>
                                                            <?php echo e($item->alamat); ?>

                                                        </span>

                                                    </td>



                                                    <td class="text-xs text-secondary opacity-7 align-middle">

                                                        <a href="<?php echo e(route('pengajar.wa', $item->no_hp)); ?>"
                                                            class="btn btn-sm custom-btn-green hover-btn"
                                                            title="Chat Whatsapp">
                                                            <i class="fa-brands fa-whatsapp text-white fs-10"> </i></a>

                                                        <a href="<?php echo e(route('pengajar.edit', $item->id)); ?>"
                                                            class="btn btn-sm custom-btn-edit hover-btn" title="Edit"><i
                                                                class="fa-solid fa-pen-to-square text-white"></i></a>
                                                        <form action="<?php echo e(route('pengajar.setnonactive', $item->id)); ?>"
                                                            method="POST" style="display: inline-block;">
                                                            <?php echo method_field('POST'); ?>
                                                            <?php echo csrf_field(); ?>

                                                            <button type="submit"
                                                                class="btn btn-sm custom-btn-hapus hover-btn"
                                                                title="Ubah Status" data-id="<?php echo e($item->id); ?>"><i
                                                                    class="fa-solid fa-trash text-white fs-10"
                                                                    onclick="return confirm('apakah kamu yakin ingin mengubah status pengajar?')"></i></button>
                                                        </form>



                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/pengajar/pengajar.blade.php ENDPATH**/ ?>