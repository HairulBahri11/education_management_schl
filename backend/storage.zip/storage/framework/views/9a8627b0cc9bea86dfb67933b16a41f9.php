<?php $__env->startSection('active_petugas', 'active'); ?>
<?php $__env->startSection('show_manajemenprogram', 'show'); ?>
<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>!",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php endif; ?>



    <div class="dashboard-content px-3 pt-5">
        <div class="container">
            <div class="row mb-3">
                <div class="container">
                    <div class="col-md-5">
                        <h4 style="font-weight: bold">Petugas</h4>

                    </div>
                    <div class="col-md-5 float-end">
                        <div class="float-end">
                            <a href="<?php echo e(route('petugas.create')); ?>"
                                class="btn btn-sm custom-btn-primary text-white hover-btn"><i
                                    class="fa-solid fa-circle-plus text-white"></i>Tambah</a>

                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="box-content">
                        <div class="col">
                            <div class="p-3">
                                <div class="table-responsive">
                                    <table class="table table-hover" id="example">
                                        <thead class="bg-gray-100 p-1">
                                            <tr style="bg-color: black" class="mt-2">
                                                <th class="text-xs text-secondary font-weight-bolder opacity-7">Foto</th>
                                                <th class="text-xs text-secondary font-weight-bolder opacity-7">Nama petugas
                                                </th>
                                                <th class="text-xs text-secondary font-weight-bolder opacity-7">Whatsapp
                                                </th>
                                                <th class="text-xs text-secondary font-weight-bolder opacity-7">alamat</th>


                                                <th class="text-xs text-secondary font-weight-bolder opacity-7">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td align-middle>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <img src="<?php echo e(asset('storage/images/' . $item->photo)); ?>"
                                                                    width="100" height="100" alt="gambar">
                                                            </div>

                                                        </div>
                                                    </td>

                                                    <td
                                                        class="text-xs text-secondary font-weight-bolder opacity-7 align-middle">
                                                        <?php echo e($item->nama_petugas); ?>

                                                    </td>
                                                    <td
                                                        class="text-xs text-secondary font-weight-bolder opacity-7 align-middle">
                                                        <?php echo e($item->no_hp); ?>

                                                    </td>

                                                    <td
                                                        class="text-xs text-secondary font-weight-bolder opacity-7 align-middle">
                                                        <span>
                                                            <i class="fa-solid fa-location-dot"> </i>
                                                            <?php echo e($item->alamat); ?>

                                                        </span>

                                                    </td>
                                                    <td
                                                        class="text-xs text-secondary font-weight-bolder opacity-7 align-middle">
                                                        <a href="<?php echo e(route('petugas.wa', $item->no_hp)); ?>"
                                                            class="btn btn-sm custom-btn-green hover-btn"
                                                            title="Chat Whatsapp">
                                                            <i class="fa-brands fa-whatsapp text-white fs-10"> </i></a>
                                                        <a href="<?php echo e(route('petugas.edit', $item->id)); ?>"
                                                            class="btn btn-sm custom-btn-edit hover-btn" title="Edit"><i
                                                                class="fa-solid fa-pen-to-square text-white"></i></a>
                                                        <form action="<?php echo e(route('petugas.destroy', $item->id)); ?>"
                                                            method="POST" style="display: inline-block;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit"
                                                                class="btn btn-sm custom-btn-hapus hover-btn"
                                                                title="Hapus"><i
                                                                    class="fa-solid fa-trash text-white fs-10"></i></button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>


    <script>
        function lihat(id, nama_program, kategori_program, jeniskelas, harga, gambar, deskripsi) {

            $('#nama_programLihat').text(nama_program);
            // image url
            let imageUrl = "<?php echo e(asset('storage/images')); ?>" + "/" + gambar;
            $('#gambarLihat').attr('src', imageUrl);
            $('#kategori_programLihat').text(kategori_program);
            $('#jeniskelasLihat').text(jeniskelas);
            $('#hargaLihat').text(harga);
            $('#deskripsiLihat').text(deskripsi);
            $('#myModal-show').modal('show');

        }
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/petugas/petugas.blade.php ENDPATH**/ ?>