<?php $__env->startSection('active_siswa', 'active'); ?>
<?php $__env->startSection('show_manajemensiswa', 'show'); ?>
<?php $__env->startSection('content'); ?>
    <div class="dashboard-content px-3 pt-5">
        <div class="container">
            <div class="row mb-3">
                <div class="container">
                    <div class="col-md-5">
                        <h4 style="font-weight: bold">Tambah Pendaftaran</h4>
                    </div>
                    <div class="col-md-5 float-end">
                        <form action="<?php echo e(route('pendaftaran.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="float-end">
                                <button type="submit" class="btn custom-btn-primary hover-btn text-white"> <i
                                        class="fa-solid fa-floppy-disk text-white"></i> Simpan</button>
                            </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row mb-3">
                    <div class="box-content">
                        <div class="col bg-white">
                            <div class="p-5">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Orang Tua</label>
                                            
                                            <select name="id_orangtua" class="form-control" <?php if(true): echo 'readonly'; endif; ?>>
                                                <option class="form-control" value="<?php echo e($data->pendaftaran->id_orangtua); ?>"
                                                    readonly><?php echo e($data->pendaftaran->orangtua->nama); ?>

                                                    -<?php echo e($data->pendaftaran->orangtua->email); ?></option>
                                            </select>
                                            

                                        </div>


                                        <div class="mb-3">
                                            <label for="exampleFormControlTextarea1" class="form-label">Nama Anak</label>
                                            <input type="text" class="form-control" name="nama_anak" id="harga"
                                                value="<?php echo e($data->nama_siswa); ?>" readonly placeholder="joko" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleFormControlTextarea1" class="form-label">Asal Sekolah</label>
                                            <input type="text" class="form-control" name="asal_sekolah" id="harga"
                                                placeholder="Smpn 1 kertosono" required
                                                value="<?php echo e($data->pendaftaran->asal_sekolah); ?>" readonly>
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Program</label>
                                            <select name="id_program" class="form-control" id="kategori_program"
                                                onchange="getKategori()" required>
                                                <option class="form-control">--Pilih Program</option>
                                                <?php $__currentLoopData = $program; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>" class="form-control">
                                                        <?php echo e($item->nama_program); ?> - <?php echo e($item->kategori_program); ?> -
                                                        <?php echo e($item->jeniskelas->nama_jenis_kelas); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>


                                    </div>

                                    <div class="col-md-6">


                                        <div class="mb-3">
                                            <label for="exampleFormControlTextarea1" id="label_bp" class="form-label">Bukti
                                                Pembayaran</label>
                                            <input type="file" name="bukti_pembayaran" class="form-control"
                                                id="bukti_pembayaran">
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" id="label_sp" class="form-label"
                                                hidden>Status Pembayaran</label>
                                            <input type="text" name="status_pembayaran" id="status_pembayaran"
                                                value="Sudah-Bayar" hidden>
                                            
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleFormControlTextarea1" class="form-label">Catatan</label>
                                            <textarea type="text" name="catatan" class="form-control" id="exampleFormControlTextarea1" rows="3" required> </textarea>
                                        </div>


                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<script>
    // ambil data kategori
    function getKategori() {
        var id_program = document.getElementById('kategori_program').value;

        // ajax untuk mendapatkan data kategori program
        let url = "<?php echo e(route('program.getkategori', ['id' => ':id'])); ?>";
        url = url.replace(':id', id_program);

        $.ajax({
            type: "GET",
            url: url,
            dataType: "json",
            success: function(response) {
                console.log(response.kategori_program);
                if (response.kategori_program == 'Trial') {
                    // hide status pembayaran dan bukti pembayaran
                    document.getElementById('label_sp').style.display = 'none';
                    document.getElementById('label_bp').style.display = 'none';
                    document.getElementById('status_pembayaran').style.display = 'none';
                    document.getElementById('bukti_pembayaran').style.display = 'none';

                } else {
                    document.getElementById('label_sp').style.display = 'block';
                    document.getElementById('label_bp').style.display = 'block';
                    document.getElementById('status_pembayaran').style.display = 'block';
                    document.getElementById('bukti_pembayaran').style.display = 'block';

                }
            }
        })
    }
</script>

<?php echo $__env->make('dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/pendaftaran/pendaftaran_create_datas.blade.php ENDPATH**/ ?>