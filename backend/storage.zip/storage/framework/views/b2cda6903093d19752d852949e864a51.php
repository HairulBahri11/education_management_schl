<?php $__env->startSection('active_pendaftaran', 'active'); ?>
<?php $__env->startSection('show_manajemensiswa', 'show'); ?>
<?php $__env->startSection('content'); ?>

    <style>
        #example {
            font-size: 12px;
        }
    </style>

    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>!",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php endif; ?>



    <div class="dashboard-content px-3 pt-5">
        <div class="container">
            <div class="row mb-3">
                <div class="container">
                    <div class="col-md-5">
                        <h4 style="font-weight: bold">Pendaftaran</h4>

                    </div>
                    <div class="col-md-5 float-end">
                        <div class="float-end">
                            <a href="<?php echo e(route('pendaftaran.create')); ?>"
                                class="btn btn-sm custom-btn-primary text-white hover-btn"><i
                                    class="fa-solid fa-circle-plus text-white"></i>Tambah</a>

                        </div>
                    </div>
                </div>
            </div>

            <div class="container">

                <div class="row">
                    <div class="box-content">
                        <div class="col">
                            <div class="p-3">
                                <div class="table-responsive">
                                    <table class="table table-hover" id="example">
                                        <thead class="bg-gray-100 p-1">
                                            <tr style="bg-color: black" class="mt-2">
                                                <th class="text-xs text-secondary font-weight-bolder opacity-7">Kode</th>
                                                <th class="text-xs text-secondary font-weight-bolder opacity-7">Orangtua
                                                </th>
                                                <th class="text-xs text-secondary font-weight-bolder opacity-7">Nama
                                                    Pendaftar
                                                </th>
                                                <th class="text-xs text-secondary font-weight-bolder opacity-7">Asal Sekolah
                                                </th>
                                                <th class="text-xs text-secondary font-weight-bolder opacity-7">Program</th>
                                                <th class="text-xs text-secondary font-weight-bolder opacity-7">Tanggal
                                                    Pendaftaran</th>
                                                <th class="text-xs text-secondary font-weight-bolder opacity-7">Status</th>
                                                <th class="text-xs text-secondary font-weight-bolder opacity-7">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td
                                                        class="text-xs text-secondary font-weight-bolder opacity-7 align-middle">
                                                        <span>
                                                            <?php echo e($item->kode_pendaftaran); ?>

                                                        </span>

                                                    </td>
                                                    <td
                                                        class="text-xs text-secondary font-weight-bolder opacity-7 align-middle">
                                                        <span>
                                                            <?php echo e($item->orangtua->nama); ?>

                                                        </span>
                                                    </td>

                                                    <td
                                                        class="text-xs text-secondary font-weight-bolder opacity-7 align-middle">
                                                        <span>
                                                            <?php echo e($item->nama_anak); ?>

                                                        </span>
                                                    </td>

                                                    <td
                                                        class="text-xs text-secondary font-weight-bolder opacity-7 align-middle">
                                                        <span>
                                                            <?php echo e($item->asal_sekolah); ?>

                                                        </span>
                                                    </td>
                                                    <td
                                                        class="text-xs text-secondary font-weight-bolder opacity-7 align-middle">
                                                        <span>
                                                            <?php echo e($item->program->nama_program); ?> -
                                                            <?php echo e($item->program->jeniskelas->nama_jenis_kelas); ?>

                                                        </span>
                                                    </td>
                                                    <td
                                                        class="text-xs text-secondary font-weight-bolder opacity-7 align-middle">
                                                        <span>
                                                            <?php echo e($item->tgl_daftar); ?>

                                                        </span>
                                                    </td>
                                                    <td
                                                        class="text-xs text-secondary font-weight-bolder opacity-7 align-middle">
                                                        <?php
                                                            $background = '';
                                                            if ($item->status_pembayaran == 'Menunggu-Konfirmasi') {
                                                                $background = 'bg-warning';
                                                                $status = 'Menunggu Konfirmasi';
                                                            } elseif ($item->status_pembayaran == 'Belum-Bayar') {
                                                                $background = 'bg-danger';
                                                                $status = 'Belum Bayar';
                                                            } elseif ($item->status_pembayaran == 'Sudah-Bayar') {
                                                                $background = 'bg-success';
                                                                $status = 'Sudah Bayar';
                                                            } else {
                                                                $background = 'bg-primary';
                                                                $status = 'Trial Program';
                                                            }
                                                        ?>
                                                        <span
                                                            class="<?php echo e($background); ?> text-white shadow px-2 me-2 py-1 align-middle">
                                                            <?php echo e($status); ?>

                                                        </span>
                                                    </td>

                                                    <td
                                                        class="text-xs text-secondary font-weight-bolder opacity-7 align-middle">
                                                        <ul class="navbar-nav gap-3">
                                                            <li class="nav-item dropdown">
                                                                <a class="nav-link dropdown-toggle" href="#"
                                                                    id="userDropdown" role="button"
                                                                    data-bs-toggle="dropdown" aria-haspopup="true"
                                                                    aria-expanded="false">
                                                                    <i class="fa-solid fa-cog"></i>
                                                                    <!-- Ikon yang lebih jelas, seperti ikon roda gigi -->
                                                                </a>
                                                                <div class="dropdown-menu" aria-labelledby="userDropdown">
                                                                    
                                                                    
                                                                    <small class="dropdown-item"
                                                                        onclick="lihat(<?php echo e($item->id); ?> , '<?php echo e($item->program->nama_program); ?>' , '<?php echo e($item->program->jeniskelas->nama_jenis_kelas); ?>' , '<?php echo e($item->bukti_pembayaran); ?>' , '<?php echo e($item->status_pembayaran); ?>' , '<?php echo e($item->program->harga); ?>')";
                                                                        style="color: black;" title="View"><i
                                                                            class="fa-solid fa-eye text-dark"></i>
                                                                        Konfirmasi
                                                                        Pembayaran</small>

                                                                    
                                                                </div>
                                                            </li>

                                                        </ul>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>




                                <!-- Modal -->
                                <div class="modal fade" id="myModal-show">
                                    <div class="modal-dialog modal-lg" id="myModal-show">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Detail pendaftaran</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">


                                                <div class="row">
                                                    
                                                    <div class="col-md-12">
                                                        <div class="card">
                                                            <a href="" data-lightbox="gambar">
                                                                <img src="" id="gambarLihat" data-lightbox="gambar"
                                                                    class="card-img-top" alt="gambar"
                                                                    style="max-height: 500px">
                                                            </a>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>


                                                        <form action="" method="POST" id="konfirmasi_form">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" id="btnKonfirmasi"
                                                                class="btn btn-primary">Konfirmasi</button>
                                                        </form>


                                                    </div>
                                                </div>



                                            </div>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                </dir>
            </div>


        <?php $__env->stopSection(); ?>

        <script>
            function lihat(id, nama_program, jenis_kelas, bukti_pembayaran, status_pembayaran, harga) {
                // buka modal
                $('#myModal-show').modal('show');
                // image url
                let imageUrl = "<?php echo e(asset('storage/images')); ?>" + "/" + bukti_pembayaran;
                $('#gambarLihat').attr('src', imageUrl);
                // nama program
                $('#ProgramLihat').text(nama_program);
                // kategori kelas
                $('#kategoriKelas').text(jenis_kelas);
                // deskripsi
                $('#deskripsiLihat').text(status_pembayaran);
                // harga with number_format

                let hargaFormat = new Intl.NumberFormat('id-ID', {
                    style: 'currency',
                    currency: 'IDR'
                }).format(harga);
                $('#hargaLihat').text(hargaFormat);
                // $('#hargaLihat').text(harga);

                if (status_pembayaran == "Sudah-Bayar") {
                    $('#btnKonfirmasi').css('display', 'none');
                } else {
                    $('#btnKonfirmasi').css('display', 'block');

                    // konfirmasi form kirim attribute src
                    let konfirmasiUrl = "<?php echo e(route('pendaftaran.konfirmasi', ['id' => ':id'])); ?>";
                    konfirmasiUrl = konfirmasiUrl.replace(':id', id);
                    $('#konfirmasi_form').attr('action', konfirmasiUrl);

                }

            }
        </script>

<?php echo $__env->make('dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/pendaftaran/pendaftaran.blade.php ENDPATH**/ ?>