<?php $__env->startSection('active_petugas', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="dashboard-content px-3 pt-5">
        <div class="container">
            <div class="row mb-3">
                <div class="container">
                    <div class="col-md-5">
                        <h4 style="font-weight: bold">Tambah Petugas</h4>
                    </div>
                    <div class="col-md-5 float-end">
                        <form action="<?php echo e(route('petugas.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="float-end">
                                <button type="submit" class="btn custom-btn-primary hover-btn text-white"> <i
                                        class="fa-solid fa-floppy-disk text-white"></i> Simpan</button>
                            </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row mb-3">
                    <div class="box-content">
                        <div class="col bg-white">
                            <div class="p-5">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">Nama Petugas</label>
                                            <input type="text" name="nama_petugas" class="form-control"
                                                id="exampleFormControlInput1" placeholder="Ex. Joghardi" required>
                                        </div>


                                        <div class="mb-3">
                                            <label for="exampleFormControlTextarea1" class="form-label">Whatsapp</label>

                                            <input type="number" class="form-control" name="no_hp" id="harga"
                                                placeholder="6285123456789" required>
                                        </div>


                                    </div>

                                    <div class="col-md-6">


                                        <div class="mb-3">
                                            <label for="exampleFormControlTextarea1" class="form-label">Foto</label>
                                            <input type="file" name="photo" class="form-control"
                                                id="exampleFormControlTextarea1" rows="3">
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleFormControlTextarea1" class="form-label">Alamat </label>
                                            <textarea class="form-control" name="alamat" id="exampleFormControlTextarea1" rows="3"
                                                placeholder="Alamat lengkap" required></textarea>



                                        </div>

                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/petugas/petugas_create.blade.php ENDPATH**/ ?>