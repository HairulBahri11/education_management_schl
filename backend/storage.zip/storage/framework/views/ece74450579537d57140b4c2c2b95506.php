<?php $__env->startSection('active_siswa', 'active'); ?>
<?php $__env->startSection('show_manajemensiswa', 'show'); ?>
<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>!",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php elseif(session('error')): ?>
        <script>
            swal({
                title: "Opps!",
                text: "<?php echo e(session('error')); ?>!",
                icon: "error",
                button: "OK",
            });
        </script>
    <?php endif; ?>



    <div class="dashboard-content px-3 pt-5">
        <div class="container">
            <div class="row mb-3">
                <div class="container">
                    <div class="col-md-5">
                        <h4 style="font-weight: bold">Siswa</h4>

                    </div>
                    
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="box-content">
                        <div class="col">
                            <div class="p-3">
                                <div class="table-responsive">
                                    <table class="table table-hover" id="example">
                                        <thead class="bg-gray-100 p-1">
                                            <tr style="bg-color: black" class="mt-2">
                                                <th class="text-xs text-secondary opacity-7">Foto</th>
                                                <th class="text-xs text-secondary opacity-7">Kode Siswa</th>
                                                <th class="text-xs text-secondary opacity-7">Nama Siswa
                                                </th>
                                                <th class="text-xs text-secondary opacity-7">Gender</th>
                                                
                                                <th class="text-xs text-secondary opacity-7">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td align-middle>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <img src="<?php echo e(asset('storage/images/' . $item->foto)); ?>"
                                                                    width="100" height="100" alt="gambar">
                                                            </div>

                                                        </div>
                                                    </td>
                                                    <td class="text-secondary opacity-7 align-middle">
                                                        <div class="user-info " align="center">
                                                            <p><?php echo e($item->kode_siswa); ?></p>
                                                            <?php echo QrCode::size(50)->generate($item->kode_siswa); ?>

                                                        </div>
                                                    </td>
                                                    <td class="text-secondary opacity-7 align-middle">
                                                        <div class="user-info">
                                                            <p class="user-name"><?php echo e($item->nama_siswa); ?></p>

                                                        </div>
                                                    </td>

                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php if($item->jenis_kelamin == 'L'): ?>
                                                            Laki Laki
                                                        <?php else: ?>
                                                            Perempuan
                                                        <?php endif; ?>
                                                    </td>

                                                    



                                                    <td class="text-xs text-secondary opacity-7 align-middle">

                                                        <small class="btn btn-sm btn-info hover-btn"
                                                            onclick="detail(<?php echo e($item->id); ?>)";
                                                            style="border-radius: 8px; border: none" title="View"><i
                                                                class="fa-solid fa-eye text-white"></i></small>

                                                        <a href="<?php echo e(route('siswa.edit', $item->id)); ?>"
                                                            class="btn btn-sm custom-btn-edit hover-btn" title="Edit"><i
                                                                class="fa-solid fa-pen-to-square text-white"></i></a>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="myModal-show">
            <div class="modal-dialog modal-lg" id="myModal-show">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Detail Siswa</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body mt-3">
                        <div class="container">

                            <div class="row">
                                <div class="col-md-6 ">
                                    <div class="card-box-shadow">
                                        <b>
                                            <sPan id="nama_siswa"></sPan>
                                        </b>
                                        <br>
                                        <img src="" id="gambarLihat" alt="gambar" width="100" height="100">

                                    </div>
                                </div>
                                <div class="col-md-6 ">
                                    <div class="card-box-shadow">
                                        <div class="col">
                                            <img class="img-icon" src="" id="gambarOrangTua" alt="">
                                        </div>
                                        <div class="col-md-12">
                                            <label for="">Orang Tua</label>
                                            <b>
                                                <p id="nama_orangtua"></p>
                                            </b>
                                        </div>
                                        <div class="col-md-10">
                                            <label for="">No Telp</label>
                                            <b>
                                                <a href="" id="waUrl"
                                                    class="btn btn-sm custom-btn-green hover-btn form-control"
                                                    title="Chat Whatsapp">
                                                    <i class="fa-brands fa-whatsapp text-white fs-10"> </i></a>
                                            </b>
                                        </div>


                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="float-end">
                                                    <a href="" id="gotoTambah"
                                                        class="btn btn-sm custom-btn-primary text-white hover-btn"><i
                                                            class="fa-solid fa-circle-plus text-white"></i>Tambah</a>
                                                </div>
                                                <h5 class="card-title">Daftar Program</h5>

                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col">Kode Pendaftaran</th>
                                                                <th scope="col">Nama Program</th>
                                                                <th scope="col">Kategori</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody id="tableBody">

                                                        </tbody>
                                                    </table>
                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<script>
    function detail(id) {
        $('#myModal-show').modal('show');
        var url = "<?php echo e(route('siswa.show', ['id' => ':id'])); ?>";
        url = url.replace(':id', id);
        //membuat url dengan parameter id untuk mengarahkan ke pendaftaran_create_datas
        var url_adds = "<?php echo e(route('pendaftaran.hal_tambahbarunew', ['id' => ':id'])); ?>";
        url_adds = url_adds.replace(':id', id);
        // ganti attribut href pada id = gotoTambah
        $('#gotoTambah').attr('href', url_adds);
        $.ajax({
            url: url,
            type: 'GET',
            dataType: "json",
            success: function(data) {
                console.log(data);
                $('#nama_siswa').text(data.data.nama_siswa);
                $('#nama_orangtua').text(data.orangtua.nama);
                let imageUrl = "<?php echo e(asset('storage/images')); ?>" + "/" + data.data.foto;
                $('#gambarLihat').attr('src', imageUrl);
                let waUrl = "<?php echo e(route('siswa.wa', ['nohp' => ':id'])); ?>";
                waUrl = waUrl.replace(':id', data.orangtua.no_hp);
                $('#waUrl').attr('href', waUrl);
                let imageOrtua = "<?php echo e(asset('storage/images')); ?>" + "/" + data.orangtua.foto;
                $('#gambarOrangTua').attr('src', imageOrtua);

                // Membersihkan tabel sebelum mengisi ulang
                $('#tableBody').empty();

                for (let i = 0; i < data.program.length; i++) {
                    let row = "<tr>";
                    row += "<td>" + data.program[i].kode_pendaftaran + "</td>";
                    row += "<td>" + data.program[i].program.nama_program + "</td>";
                    row += "<td>" + data.program[i].program.kategori_program + "</td>";
                    row += "</tr>";
                    $('#tableBody').append(row);
                }






            }
        });


    }
</script>

<?php echo $__env->make('dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/siswa/siswa.blade.php ENDPATH**/ ?>