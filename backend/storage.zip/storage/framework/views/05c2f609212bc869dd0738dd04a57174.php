<?php $__env->startSection('content'); ?>
    <section class="py-2">
        <div class="container">
            <div class="row">
                <h4 class=" mt-2 fw-bold"> Data Pendaftaran</h4>
            </div>
            <div class="row">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-4">
                        <div class="box-card-custom bg-white p-3" style="border-radius: 10px">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card border-1 ">
                                        <div class="card-body ">

                                            <div class="row">
                                                <div class="col-md-12">

                                                    <div class="prfil d-flex justify-content-center align-items-center">
                                                        <img src="<?php echo e(asset('storage/images/' . $data->foto)); ?>"
                                                            class="img-fluid rounded-circle d-flex justify-content-center align-items-center"
                                                            style="width: 60px; height: 60px; object-fit: cover; object-position: center  }}"
                                                            alt="">
                                                    </div>


                                                    <p class="card-text text-secondary text-center fw-bold mt-2">
                                                        <?php echo e($data->nama_siswa); ?></p>
                                                    </p>

                                                    <div class="qr d-flex justify-content-center align-items-center ">
                                                        <p><?php echo QrCode::size(70)->generate($data->kode_siswa); ?></p>
                                                    </div>
                                                    <p class=" text-secondary text-center">
                                                        <img src="<?php echo e(asset('logo.png')); ?>" class="img-fluid"
                                                            style="width: 40px; height: 30px" alt="">
                                                        Student Center
                                                    </p>
                                                    <p class="text-secondary text-center" style="font-size: 12px">Jln.
                                                        Manggasari Probolinggo Jawa Timur </p>
                                                    <a href="<?php echo e(route('pendaftaran.detail', $data->id)); ?>"
                                                        class="btn btn-success form-control btn-sm mt-2">
                                                        Detail Siswa
                                                    </a>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard-orangtua/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard-orangtua/pendaftaran/ortu-pendaftaran.blade.php ENDPATH**/ ?>