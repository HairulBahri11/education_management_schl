<?php $__env->startSection('active_absensi', 'active'); ?>
<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>!",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php elseif(session('error')): ?>
        <script>
            swal({
                title: "Oops!",
                text: "<?php echo e(session('error')); ?>!",
                icon: "error",
                button: "OK",
            });
        </script>
    <?php endif; ?>



    <div class="dashboard-content px-3 pt-5">
        <div class="container">
            <div class="row mb-2">
                <div class="container">
                    <div class="col-md-5">
                        <h4 style="font-weight: bold">Tambah Absensi

                        </h4>
                    </div>
                    <div class="col-md-5 ms-auto">
                        <form action="<?php echo e(route('absensi.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="float-end">
                                <button type="submit" class="btn custom-btn-primary hover-btn text-white"> <i
                                        class="fa-solid fa-floppy-disk text-white"></i> Simpan</button>
                            </div>
                    </div>
                </div>
            </div>
            <div class="container">

                <div class="row mb-3">
                    <div class="box-content">
                        <div class="col-md-12 p-4">
                            
                            <div class="absent-data mb-3">
                                <label for="exampleInputEmail1" class="form-label">Jadwal</label>
                                <select name="jadwal_id" id="jadwal_id" class="form-control" onchange="getJadwal()">
                                    <option value=""> --Pilih Jadwal--</option>
                                    <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="form-control" value="<?php echo e($jadwal->id); ?>">
                                            <?php echo e($jadwal->kelas->nama_kelas); ?> - <?php echo e($jadwal->pengajar->nama); ?> -
                                            <?php echo e($jadwal->kelas->program->nama_program); ?> - <?php echo e($jadwal->hari); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Tanggal</label>
                                <input type="date" name="tgl_absen" id="date" class="form-control">

                            </div>

                            <div class="absent-baru">

                            </div>
                        </div>

                        <input type="text" name="value_all_jadwal[]" id="value_all_jadwal" hidden>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        function getJadwal() {
            var jadwal_id = $('#jadwal_id').val();
            url = "<?php echo e(route('absensi.getjadwal', ':id')); ?>".replace(':id', jadwal_id);
            $.ajax({
                type: "GET",
                url: url,
                dataType: "json",
                success: function(response) {
                    $('#value_all_jadwal').val(response.data.id);
                    console.log(response.data.id);
                }

            })
        }

        $(document).on('click', '#btn-add', function() {
            var jadwal_id = $('#value_all_jadwal').val();
            url = "<?php echo e(route('newgetdatajadwal', ':id')); ?>".replace(':id', jadwal_id);
            $.ajax({
                type: "GET",
                url: url,
                dataType: "json",
                success: function(response) {
                    console.log(response);
                    $('.absent-baru').append(response);
                    $('#btn-add').addClass('d-none');
                }
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/absensi/absensi_create.blade.php ENDPATH**/ ?>