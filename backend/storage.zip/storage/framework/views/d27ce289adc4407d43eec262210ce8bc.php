<?php $__env->startSection('active_raport', 'active'); ?>
<?php $__env->startSection('show_manajemennilai', 'show'); ?>
<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>!",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php elseif(session('error')): ?>
        <script>
            swal({
                title: "Oops!",
                text: "<?php echo e(session('error')); ?>!",
                icon: "error",
                button: "OK",
            });
        </script>
    <?php endif; ?>



    <div class="dashboard-content px-3 pt-5">
        <div class="container">
            <div class="row mb-2">
                <div class="container">
                    <div class="col-md-5">
                        <h4 style="font-weight: bold">Data Kelas </h4>
                    </div>

                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="box-content">
                        <div class="col">
                            <div class="p-3">
                                <div class="table-responsive">
                                    <table class="table table-hover" id="example">
                                        <thead class="bg-gray-100 p-1">
                                            <tr style="bg-color: black" class="mt-2">
                                                <th class="text-xs text-secondary opacity-7">Kelas</th>
                                                <th class="text-xs text-secondary opacity-7">Program
                                                </th>
                                                <th class="text-xs text-secondary opacity-7">Durasi</th>
                                                <th class="text-xs text-secondary opacity-7">Jumlah Siswa</th>
                                                <th class="text-xs text-secondary opacity-7">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php echo e($item->nama_kelas); ?>

                                                    </td>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php echo e($item->program->nama_program); ?> -
                                                        <?php echo e($item->program->jeniskelas->nama_jenis_kelas); ?>

                                                    </td>
                                                    
                                                    
                                                    <?php
                                                        $siswa = App\Models\Manajemen_Kelas::where('kelas_id', $item->id)->count();
                                                        $data_siswa = App\Models\Manajemen_Kelas::where('kelas_id', $item->id)->first();

                                                        $status = $item->status;
                                                        if ($status == 'aktif') {
                                                            $icon = 'fa fa-check-circle text-success';
                                                        } else {
                                                            $icon = 'fa fa-times-circle text-danger';
                                                        }
                                                    ?>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <span>
                                                            <i class="fa-solid fa-calendar-days"> </i>
                                                            <?php echo e($data_siswa->tgl_mulai); ?> | <?php echo e($data_siswa->tgl_selesai); ?>

                                                        </span>
                                                    </td>


                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <span>
                                                            <i class="fa-solid fa-users"> </i>
                                                            <?php echo e($siswa); ?> Siswa
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('raport_kelas.detail', $item->id)); ?>"
                                                            class="btn btn-sm custom-btn-edit text-white hover-btn"
                                                            title="Detail"><i class="fa-solid fa-eye text-white"></i></a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/raport/kelas.blade.php ENDPATH**/ ?>