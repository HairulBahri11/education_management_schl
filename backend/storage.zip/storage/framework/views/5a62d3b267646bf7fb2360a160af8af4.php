<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <link rel="stylesheet" href="<?php echo e(asset('landing.css')); ?>" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@300&family=Open+Sans:ital,wght@0,400;0,600;0,700;1,600&display=swap"
        rel="stylesheet">
    <link href="https://cdn.datatables.net/v/dt/dt-1.13.6/datatables.min.css" rel="stylesheet">

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <title>Landing Page</title>
</head>
<style>
    .box {
        max-width: 500px;
        /* Sesuaikan dengan lebar maksimal yang Anda inginkan */
        margin: 0 auto;
        /* Untuk meletakkan elemen di tengah halaman */
    }
</style>

<body>

    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>!",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php elseif(session('error')): ?>
        <script>
            swal({
                title: "Oops!",
                text: "<?php echo e(session('error')); ?>!",
                icon: "error",
                button: "OK",
            });
        </script>
    <?php endif; ?>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-md bg-white py-3">
        <div class="container">
            <a href="#" class="navbar-brand text-uppercase navbar-text-truncate">
                <img src="<?php echo e(asset('logo.png')); ?>" width="67" height="67" alt="logo">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
                <span class="navbar-toggler-icon">
                    <i class="fas fa-bars text-primary"></i>
                </span>
            </button>
            <div class="collapse navbar-collapse" id="navMenu">
                <ul class="navbar-nav gap-1 ms-auto ">
                    <li class="nav-item"><a href="<?php echo e(route('landingpage')); ?>" class="nav-link ">Home</a></li>

                    <li class="nav-item"><a href="." class="nav-link active">Dashboard</a></li>
                </ul>
                <ul class="navbar-nav gap-3 ms-auto">
                    <?php if(Auth::check()): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="<?php echo e(asset('storage/images/' . Auth::user()->foto)); ?>"
                                    class="img-thumbnail rounded-circle" width="30" height="30"
                                    alt="<?php echo e(Auth::user()->nama); ?>">
                                <?php echo e(Auth::user()->nama); ?>

                            </a>
                            <div class="dropdown-menu" aria-labelledby="userDropdown">

                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i
                                        class="fa-solid fa-arrow-right-from-bracket"></i> Logout</a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>

                            </div>
                        </li>
                    <?php else: ?>
                        <li class="nav-item"><a href="<?php echo e(route('login')); ?>"
                                class="nav-link btn btn-outline-primary text-primary" style="width:100px">Login</a></li>
                        <li class="nav-item"><a href="<?php echo e(route('register')); ?>"
                                class="btn btn-primary fw-medium px-4 py-2">Register</a></li>
                    <?php endif; ?>
                </ul>

            </div>
        </div>
    </nav>
    <!-- endNavbar -->

    <header class="py-5">
        <div class="container">
            <h1 class="align-items-center justify-content-center text-primary text-center text-capitalize mb-5"
                style="font-weight: bold">Tempat Belajar Teknologi di Kota Probolinggo</h1>
            <p class="text-secondary text-center text-capitalize">
                Tempat belajar sambil bermain anak-anak Proboliggo dengan mengulik alat dan kemajuan ilmu digital
            </p>
            <!-- form pencarian -->

            <div class="btn-posisi d-flex justify-content-center gap-3 mt-3 align-items-center ">
                <div class="btn btn-primary rounded-8" style="width: 200px">Program Trial</div>
                <div class="btn btn-outline-primary rounded-8" style="width: 200px"> Program Premium</div>

            </div>
        </div>
    </header>

    <?php echo $__env->yieldContent('content'); ?>


</body>

</html>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard-orangtua/index.blade.php ENDPATH**/ ?>