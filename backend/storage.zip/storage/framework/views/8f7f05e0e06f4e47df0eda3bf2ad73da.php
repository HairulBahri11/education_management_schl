<?php $__env->startSection('active_absensi', 'active'); ?>
<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>!",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php elseif(session('error')): ?>
        <script>
            swal({
                title: "Oops!",
                text: "<?php echo e(session('error')); ?>!",
                icon: "error",
                button: "OK",
            });
        </script>
    <?php endif; ?>



    <div class="dashboard-content px-3 pt-5">
        <div class="container">
            <div class="row mb-2">
                <div class="container">
                    <div class="col-md-5">
                        <h4 style="font-weight: bold">Absensi Kelas

                        </h4>
                    </div>
                    <div class="col-md-5 ms-auto">
                        <div class="float-end">
                            <a href="<?php echo e(route('absensi.create')); ?>"
                                class="btn btn-sm custom-btn-primary text-white hover-btn"><i
                                    class="fa-solid fa-circle-plus text-white"></i>Tambah Absensi</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="box-content">
                        <div class="col">
                            <div class="p-3">
                                <div class="table-responsive">
                                    <table class="table table-hover" id="example">
                                        <thead class="bg-gray-100 p-1">
                                            <tr style="bg-color: black" class="mt-2">
                                                <th class="text-xs text-secondary opacity-7">Tanggal</th>
                                                <th class="text-xs text-secondary opacity-7">Pengajar</th>
                                                <th class="text-xs text-secondary opacity-7">Hari</th>
                                                <th class="text-xs text-secondary opacity-7">Jam</th>
                                                <th class="text-xs text-secondary opacity-7">Kelas</th>
                                                <th class="text-xs text-secondary opacity-7">Program
                                                </th>
                                                
                                                <th class="text-xs text-secondary opacity-7">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php echo e($item->tgl_absen); ?>

                                                    </td>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php echo e($item->pengajar->nama); ?>

                                                    </td>

                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php echo e($item->jadwal->hari); ?></td>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php echo e(\Illuminate\Support\Carbon::parse($item->jadwal->jam_mulai)->format('H:i')); ?>

                                                        -
                                                        <?php echo e(\Illuminate\Support\Carbon::parse($item->jadwal->jam_selesai)->format('H:i')); ?>

                                                    </td>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">
                                                        <?php echo e($item->kelas->nama_kelas); ?>

                                                    </td>
                                                    <td class="text-xs text-secondary opacity-7 align-middle">

                                                        <?php echo e($item->kelas->program->nama_program); ?> -
                                                        <?php echo e($item->kelas->program->jeniskelas->nama_jenis_kelas); ?>

                                                    </td>
                                                    


                                                    <td class="text-xs text-secondary opacity-7 align-middle">

                                                        
                                                        <?php
                                                            $id_absensi = $item->id;
                                                            $data_absensi_detail = \App\Models\Absensi_Detail::where('absensi_id', $id_absensi)->get();
                                                            if ($data_absensi_detail->count() > 0) {
                                                                $show_detail = 'd-blok';
                                                                $create_detail = 'd-none';
                                                            } else {
                                                                $show_detail = 'd-none';
                                                                $create_detail = 'd-blok';
                                                            }

                                                        ?>
                                                        <form action="<?php echo e(route('absensi_detail.store', $item->id)); ?>"
                                                            method="POST" style="display: inline-block;">
                                                            <?php echo method_field('POST'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit"
                                                                class="btn btn-sm custom-btn-green hover-btn <?php echo e($create_detail); ?>"
                                                                title="Kelola Absen" data-id="<?php echo e($item->id); ?>"><i
                                                                    class="fa-solid fa-pencil text-white fs-10"></i></button>
                                                        </form>
                                                        <a href="<?php echo e(route('absensi_detail.edit', $item->id)); ?>"
                                                            class="btn btn-sm custom-btn-edit hover-btn <?php echo e($show_detail); ?>"
                                                            title="Edit"><i
                                                                class="fa-solid fa-pen-to-square text-white"></i></a>.
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/absensi/absensi.blade.php ENDPATH**/ ?>