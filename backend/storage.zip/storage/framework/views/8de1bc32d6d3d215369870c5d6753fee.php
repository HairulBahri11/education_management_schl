<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required Meta Tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS with cdn -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@300&family=Open+Sans:ital,wght@0,400;0,600;0,700;1,600&display=swap"
        rel="stylesheet">
    <link href="https://cdn.datatables.net/v/dt/dt-1.13.6/datatables.min.css" rel="stylesheet">

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">


    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://cdn.ckeditor.com/ckeditor5/40.0.0/classic/ckeditor.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css">
    <title>Admin Sidebar</title>

</head>

<body>

    <div class="main-container d-flex">
        <div class="sidebar" id="side_nav">
            <div class="header-box px-4 pt-3 pb-2 d-flex justify-content-between" style="background-color: white;">
                
                <img src="<?php echo e(asset('logo.png')); ?>" height="38px" class=" px-3" alt="">
                <button class="btn d-md-none d-block close-btn px-1 py-0 text-white"><i
                        class="fal fa-stream"></i></button>
            </div>

            <span class="menu-icon d-none d-block mt-5">
            </span>
            <ul class="list-unstyled px-3">

                <span class=""><a href="#" class="text-decoration-none px-3 py-2 d-block"
                        style="color: #f9f9f9;">Menu</a></span>

                <?php if(Auth::user()->role == 'admin'): ?>
                    <li class="<?php echo $__env->yieldContent('active_dashboard'); ?>"><a href="<?php echo e(route('dashboard')); ?>"
                            class="text-decoration-none px-3 py-2 d-block "><i
                                class="fa-solid fa-house"></i>Dashboard</a>
                    </li>
                <?php else: ?>
                    <li class="<?php echo $__env->yieldContent('active_dashboard'); ?>"><a href="<?php echo e(route('dashboard-ortu')); ?>"
                            class="text-decoration-none px-3 py-2 d-block "><i
                                class="fa-solid fa-house"></i>Dashboard</a>
                    </li>
                <?php endif; ?>

                <?php if(Auth::user()->role == 'orangtua'): ?>
                    <li class="<?php echo $__env->yieldContent('active_pendaftaran'); ?>"><a href="<?php echo e(route('pendaftaran.index.ortu')); ?>"
                            class="text-decoration-none px-3 py-2 d-block "><i
                                class="fa-solid fa-landmark"></i>Pendaftaran</a>
                <?php endif; ?>


                </li>
                <?php if(Auth::user()->role == 'admin'): ?>
                    <li class="<?php echo $__env->yieldContent('active_pengajar'); ?>"><a href="<?php echo e(route('pengajar')); ?>"
                            class="text-decoration-none px-3 py-2 d-block"><i
                                class="fa-solid fa-chalkboard-user"></i>Pengajar</a></li>
                    

                    <span class="mb-1">
                        <a href="#" class="d-flex align-items-start px-3 py-2 text-decoration-none"
                            style="color: #284a5e;" data-bs-toggle="collapse" data-bs-target="#home-collapse"
                            aria-expanded="true">
                            <i class="fa-solid fa-landmark" style=" padding-right: 19px;"></i>
                            Manajemen Program
                            <i class="fa-solid fa-angle-down ms-auto"></i>

                        </a>
                        <div class="collapse <?php echo $__env->yieldContent('show_manajemenprogram'); ?> " id="home-collapse">
                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small px-5">
                                <li class="<?php echo $__env->yieldContent('active_program'); ?>"><a href="<?php echo e(route('program.index')); ?>"
                                        class="text-decoration-none px-3 py-2 d-block"></i>Program</a>
                                </li>
                                <li class="<?php echo $__env->yieldContent('active_petugas'); ?>"><a href="<?php echo e(route('petugas.index')); ?>"
                                        class="text-decoration-none px-3 py-2 d-block">Petugas</a></li>
                                <li class="<?php echo $__env->yieldContent('active_ruangan'); ?>"><a href="<?php echo e(route('ruangan.index')); ?>"
                                        class="text-decoration-none px-3 py-2 d-block">Ruangan</a></li>

                            </ul>
                        </div>

                    </span>
                    <span class="mb-1">
                        <a href="#" class="d-flex align-items-center px-3 py-2 text-decoration-none"
                            style="color: #284a5e;" data-bs-toggle="collapse" data-bs-target="#man-siswa-collapse"
                            aria-expanded="true">
                            <i class="fa-solid fa-users" style="padding-right: 16px"></i>
                            Manajemen Siswa
                            <i class="fa-solid fa-angle-down ms-auto"></i>
                        </a>

                        <div class="collapse <?php echo $__env->yieldContent('show_manajemensiswa'); ?> " id="man-siswa-collapse">
                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small px-5">
                                <li class="<?php echo $__env->yieldContent('active_orangtua'); ?>"><a href="<?php echo e(route('orangtua.index')); ?>"
                                        class="text-decoration-none px-3 py-2 d-block"></i>Orang Tua</a>
                                </li>
                            </ul>
                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small px-5">
                                <li class="<?php echo $__env->yieldContent('active_pendaftaran'); ?>"><a href="<?php echo e(route('pendaftaran.index')); ?>"
                                        class="text-decoration-none px-3 py-2 d-block"></i>Pendaftaran</a>
                                </li>
                            </ul>
                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small px-5">
                                <li class="<?php echo $__env->yieldContent('active_siswa'); ?>"><a href="<?php echo e(route('siswa.index')); ?>"
                                        class="text-decoration-none px-3 py-2 d-block"></i>Siswa</a>
                                </li>
                            </ul>
                        </div>
                    </span>
                    <span class="mb-1">
                        <a href="#" class="d-flex align-items-center px-3 py-2 text-decoration-none"
                            style="color: #284a5e;" data-bs-toggle="collapse" data-bs-target="#man-kelas-collapse"
                            aria-expanded="true">
                            <i class="fa-solid fa-shop" style="padding-right: 16px"></i>

                            Manajemen Kelas
                            <i class="fa-solid fa-angle-down ms-auto"></i>
                        </a>

                        <div class="collapse <?php echo $__env->yieldContent('show_manajemenkelas'); ?> " id="man-kelas-collapse">
                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small px-5">

                                <li class="<?php echo $__env->yieldContent('active_kelas'); ?>"><a href="<?php echo e(route('kelas.index')); ?>"
                                        class="text-decoration-none px-3 py-2 d-block">Kelas</a></li>
                                <li class="<?php echo $__env->yieldContent('active_jadwalkelas'); ?>"><a href="<?php echo e(route('jadwalpremium.index')); ?>"
                                        class="text-decoration-none px-3 py-2 d-block">Jadwal Kelas</a>
                                </li>
                                <li class="<?php echo $__env->yieldContent('active_jadwaltrial'); ?>"><a href="<?php echo e(route('jadwaltrial.index')); ?>"
                                        class="text-decoration-none px-3 py-2 d-block">Jadwal Trial</a>
                                </li>
                            </ul>
                        </div>
                    </span>
                <?php endif; ?>
                <li class="<?php echo $__env->yieldContent('active_absensi'); ?>"><a href="<?php echo e(route('absensi.index')); ?>"
                        class="text-decoration-none px-3 py-2 d-block "><i
                            class="fa-regular fa-calendar-check fs-5"></i>Kehadiran</a>
                </li>
                <span class="mb-1">
                    <a href="#" class="d-flex align-items-center px-3 py-2 text-decoration-none"
                        style="color: #284a5e;" data-bs-toggle="collapse" data-bs-target="#man-penilaian"
                        aria-expanded="true">
                        <i class="fa-solid fa-marker" style="padding-right: 16px"></i>

                        Manajemen Nilai
                        <i class="fa-solid fa-angle-down ms-auto"></i>
                    </a>

                    <div class="collapse <?php echo $__env->yieldContent('show_manajemennilai'); ?> " id="man-penilaian">
                        <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small px-5">
                            <li class="<?php echo $__env->yieldContent('active_aspekpenilaian'); ?>"><a href="<?php echo e(route('aspekpenilaian.index')); ?>"
                                    class="text-decoration-none px-3 py-2 d-block">Aspek Penilain</a></li>
                            <li class="<?php echo $__env->yieldContent('active_raport'); ?>"><a href="<?php echo e(route('raport_kelas.index')); ?>"
                                    class="text-decoration-none px-3 py-2 d-block">Raport Siswa</a>
                            </li>
                        </ul>
                    </div>
                </span>

            </ul>
            <hr class="h-color mx-2">

            
        </div>

        <div class="content">
            <nav class="navbar navbar-expand-md">

                <div class="container-fluid px-5">
                    <div class="d-flex justify-content-between d-md-none d-block">
                        <button class="btn px-1 py-0 open-btn me-2"><i class="fal fa-stream"></i></button>
                        <a class="navbar-brand fs-4" href="#"><span
                                class="bg-dark rounded px-2 py-0 text-white">BJ</span></a>
                    </div>

                    <button class="navbar-toggler p-0 border-0" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fal fa-bars"></i>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                        <ul class="navbar-nav">
                            <?php if(Auth::check()): ?>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown"
                                        role="button" data-bs-toggle="dropdown" aria-haspopup="true"
                                        aria-expanded="false">
                                        <span class="px-2"><?php echo e(Auth::user()->nama); ?></span>

                                        <img src="<?php echo e(asset('storage/images/' . Auth::user()->foto)); ?>"
                                            class="img-thumbnail rounded-circle" width="30" height="30"
                                            alt="<?php echo e(Auth::user()->nama); ?>">
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="userDropdown">
                                        <a class="dropdown-item text-sm" href="<?php echo e(route('landingpage')); ?>">
                                            <i class="fa-solid fa-house"></i> Home
                                        </a>
                                        <a class="dropdown-item text-sm" href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                            <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
                                        </a>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                            class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>

                                </li>
                            <?php else: ?>
                                <li class="nav-item"><a href="<?php echo e(route('login')); ?>"
                                        class="nav-link btn btn-outline-primary text-primary">Login</a></li>
                                <li class="nav-item"><a href="<?php echo e(route('register')); ?>"
                                        class="btn btn-primary fw-medium px-4 py-2">Register</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>

                </div>

            </nav>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>


    <?php echo $__env->yieldContent('js'); ?>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/v/dt/dt-1.13.6/datatables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"
        integrity="sha512-Ixzuzfxv1EqafeQlTCufWfaC6ful6WFqIz4G+dWvK0beHw0NVJwvCKSgafpy5gwNqKmgUfIBraVwkKI+Cz0SEQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $(".sidebar ul li").on('click', function() {
            $(".sidebar ul li.active").removeClass('active');
            $(this).addClass('active');
        });

        $('.open-btn').on('click', function() {
            $('.sidebar').addClass('active');
        });
        $('.close-btn').on('click', function() {
            $('.sidebar').removeClass('active');
        });

        let datatable = $('#example').DataTable({
            "order": [
                [0, "asc"]
            ], // Contoh pengurutan kolom pertama secara ascending
            "ordering": false // Menonaktifkan pengurutan otomatis
        });

        lightbox.option({
            'resizeDuration': 200,
            'wrapAround': true
        })
    </script>

</body>

</html>


<?php echo $__env->yieldPushContent('js'); ?>
<?php /**PATH C:\xampp_2\htdocs\education_management_schl\backend\resources\views/dashboard/index.blade.php ENDPATH**/ ?>